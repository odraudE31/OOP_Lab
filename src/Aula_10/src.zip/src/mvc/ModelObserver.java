package src.mvc;

public interface ModelObserver {
    void modelChanged();
}

