package sorting;

public abstract class Sort<T extends Comparable<T>> {
    public abstract T[] sort(T[] a);
}
